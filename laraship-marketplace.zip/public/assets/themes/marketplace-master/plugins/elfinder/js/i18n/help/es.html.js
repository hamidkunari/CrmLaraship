<h2>Consejos de operaci&oacute;n</h2>
<p>Operar en la Interfaz del Usuario es similar al administrador de archivos estandar del sistema operativo. Sin embargo, Arrastrar y soltar no es posible con los navegadores m&oacute;viles.</p>
<ul>
	<li>Click derecho o un tap largo para mostrar el men&uacute; de contexto.</li>
	<li>Arrastrar y soltar dentro del &aacute;rbol de carpetas o el espacio de trabajo actual para mover/copiar elementos.</li>
	<li>La selecci&oacute;n de elementos en el espacio de trabajo puede ampliarse con la tecla Shift o Alt (Opci&oacute;n).</li>
	<li>Arrastrar y soltar a la carpeta de destino o &aacute;rea de trabajo para cargar archivos y carpetas.</li>
	<li>El cuadro de di&aacute;logo de carga puede aceptar pegar/soltar datos del portapapeles o listas de URL y arrastrar y soltar desde otro navegador o administrador de archivos, etc.</li>
	<li>Iniciar a arrastrar presionando la tecla Alt (Opci&oacute;n) para arrastrar fuera del navegador. Se convertir&aacute; en una operaci&oacute;n de descarga con Google Chrome.</li>
</ul>
