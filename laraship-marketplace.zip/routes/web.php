<?php

use Illuminate\Support\Facades\Route;

Route::get('/', '\Corals\Foundation\Http\Controllers\PublicBaseController@welcome');
